// Buat agar constant dog dapat diakses dari file berikut
import Dog from "./dog";

const dog = new Dog("Leo", 4, "Chihuahua");
// Export constant dog
export default dog;
