// Definisikan constant name
const name = "Ninja Ken";

const introduce = (name) => {
  // Print "Saya ____" diconsole
  console.log(`Saya ${name}`);
};

// Panggil function introduce
introduce("Guru Domba");

// Print nilai dari constant name
console.log(name);
