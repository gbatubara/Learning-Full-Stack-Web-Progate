const characters = [
  {name: "Ninja Ken", age: 14},
  {name: "Guru Domba", age: 1000}
];

// Print element pertama milik array characters
console.log(characters[0]);

// Print nilai milik property name dari element array character kedua 
console.log(characters[1].name);
