// Deklarasikan constant character dan berikan object yang sudah disediakan
const character = {name: "Ninja Ken", age: 14};

// Print nilai character
console.log(character);
