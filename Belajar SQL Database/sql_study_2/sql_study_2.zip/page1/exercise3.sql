-- dapatkan baris dari kolom name tanpa duplikat
SELECT distinct(name)
FROM purchases;