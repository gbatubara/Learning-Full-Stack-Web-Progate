-- dapatkan baris dari kolom character_name dengan duplikat dihilangkan
SELECT Distinct(character_name)
FROM purchases;