-- dapatkan harga tertinggi di kolom price
SELECT max(price)
FROM purchases;