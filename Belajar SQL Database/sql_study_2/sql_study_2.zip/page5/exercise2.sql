-- dapatkan jumlah baris di tabel purchases 
SELECT count(*)
FROM purchases;