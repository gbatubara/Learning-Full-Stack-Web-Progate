-- dapatkan jumlah baris dikolom name dari table purchases 
SELECT count(name)
FROM purchases;