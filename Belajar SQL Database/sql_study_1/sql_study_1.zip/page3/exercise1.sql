-- Akses kolom "name" dan "price" dari tabel "purchases" 
select name, price from purchases;
