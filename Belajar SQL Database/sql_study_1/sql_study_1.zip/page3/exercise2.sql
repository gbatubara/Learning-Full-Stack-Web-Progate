-- Akses semua kolom dari tabel "purchases" 
select * from purchases;
