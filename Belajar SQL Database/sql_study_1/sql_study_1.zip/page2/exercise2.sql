-- Akses kolom "price" dari table "purchases"
SELECT price from purchases;


