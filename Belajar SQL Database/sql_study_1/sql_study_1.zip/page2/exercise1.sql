-- Akses kolom "name" dari tabel "purchases" 
SELECT name from purchases;
