/*
dibawah WHERE character_name = "Ninja Ken",
tambahkan code untuk menampilkan hasil maksimum 10 baris
*/

SELECT *
FROM purchases
WHERE character_name = "Ninja Ken"
limit 10;